#target Photoshop

function pad(num, size){ return ('000000000' + num).substr(-size); }

var textlayer = app.activeDocument.layers.getByName('lv');

for (i=1; i<25;i++)
{
	textlayer.textItem.contents = 'LEVEL '+i;
	var exportOptionsSaveForWeb = new ExportOptionsSaveForWeb();
	exportOptionsSaveForWeb.format = SaveDocumentType.PNG;

	var saveFile = new File("file:///F:/Games/Rave It Out/RaveItOut/RaveItOut/Random Stuff/Uncropped Group Banners/temp/"+pad(i,2)+".png");
	app.activeDocument.exportDocument(saveFile, ExportType.SAVEFORWEB, exportOptionsSaveForWeb);
}