#target Photoshop

function pad(num, size){ return ('000000000' + num).substr(-size); }

function collectAllLayers (doc, allLayers){
    for (var m = 0; m < doc.layers.length; m++){
        var theLayer = doc.layers[m];
        if (theLayer.typename === "ArtLayer"){
            allLayers.push(theLayer);
        }else{
            collectAllLayers(theLayer, allLayers);
        }
    }
    return allLayers;
}
var allLayers = [];
var allLayers = collectAllLayers(app.activeDocument, allLayers);
/*alert(allLayers)
var s = ""
for (i=0; i<allLayers.length; i++)
	//if (l === undefined)
		//alert("failure")
		//throw ''
		//throw ''
	s += allLayers[i].typename+", "
alert(s)
throw ''*/

function dumbLayerSearch(name)
{
	for (var i=0; i<allLayers.length; i++)
	{
		//alert(l.name)
		if (allLayers[i].name == name)
		{
			return allLayers[i];
		}
	}
	alert("Shouldn't get this far! Searched for "+name)
	return null;
}
var textlayer = app.activeDocument.layers.getByName('bpm');

//Make rectangles invisible
for (var i=1; i<26;i++)
{
	dumbLayerSearch("Rectangle "+i).visible = false
	//IT DOESN'T WORK!!!
	//app.activeDocument.artLayers.getByName("Rectangle 1").visible = false
	//app.activeDocument.artLayers.getByName("Rectangle "+i).visible = false
}

var savedName = "Saved "
for (var i=0; i<25;i++)
{
	dumbLayerSearch("Rectangle "+(i+1)).visible = true
	textlayer.textItem.contents = 'BPM '+(i*20)+"-"+(i*20+19);
	var exportOptionsSaveForWeb = new ExportOptionsSaveForWeb();
	exportOptionsSaveForWeb.format = SaveDocumentType.PNG;

	var fileName = pad(i*20,3)+"-"+pad(i*20+19,3)+".png"
	var saveFile = new File("file:///F:/Games/Rave It Out/RaveItOut/RaveItOut/Random Stuff/Uncropped Group Banners/temp/"+fileName);
	//savedName+=""+(i*20)+".png, "
	app.activeDocument.exportDocument(saveFile, ExportType.SAVEFORWEB, exportOptionsSaveForWeb);
	
}
//alert(savedName)