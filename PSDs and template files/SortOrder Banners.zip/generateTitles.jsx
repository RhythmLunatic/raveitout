#target Photoshop

//function pad(num, size){ return ('000000000' + num).substr(-size); }

upperCaseAlp = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0-9"]

var textlayer = app.activeDocument.layers.getByName('l');

for (i=0; i<upperCaseAlp.length;i++)
{
	textlayer.textItem.contents = upperCaseAlp[i];
	var exportOptionsSaveForWeb = new ExportOptionsSaveForWeb();
	exportOptionsSaveForWeb.format = SaveDocumentType.PNG;

	var saveFile = new File("file:///F:/Games/Rave It Out/RaveItOut/RaveItOut/Random Stuff/Uncropped Group Banners/temp/"+upperCaseAlp[i]+".png");
	app.activeDocument.exportDocument(saveFile, ExportType.SAVEFORWEB, exportOptionsSaveForWeb);
}